package com.example.lenovo.nanu_garg;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int Active_player =0;
    int gamestate[]={2,2,2,2,2,2,2,2,2};
    int[][] winning_positins={{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};

    public void dropin(View view) {
        ImageView counter = (ImageView) view;


        System.out.println(counter.getTag().toString());
        int tappedCounter = Integer.parseInt(counter.getTag().toString());
        if (gamestate[tappedCounter] == 2) {
            gamestate[tappedCounter]=Active_player;
            counter.setTranslationY(-1000f);
            if (Active_player == 0) {
                counter.setImageResource(R.drawable.download);

                Active_player = 1;
            } else {
                counter.setImageResource(R.drawable.yellow);

                Active_player = 0;
            }
            counter.animate().translationYBy(1000f).setDuration(100);
for(int[] Winningposition: winning_positins)

{
if(gamestate[Winningposition[0]]==gamestate[Winningposition[1]]&&gamestate[Winningposition[1]]==gamestate[Winningposition[2]]&&gamestate[Winningposition[0]]!=2)
{
    String a;
    a="yellow";
    if(gamestate[Winningposition[0]]==0){
         a="red";}

    TextView text=(TextView)findViewById(R.id.messagedisplay);
    text.setText(a+" has won");
    LinearLayout layout=(LinearLayout)findViewById(R.id.playagainlayout);
    layout.setVisibility(view.VISIBLE);

}
else
{
    boolean gameover=true;
    for(int cs: gamestate)
    {
        if(cs==2)
        {gameover=false;}
    }
    if(gameover)
    {
        TextView text=(TextView)findViewById(R.id.messagedisplay);
        text.setText("DRAWW");
        LinearLayout layout=(LinearLayout)findViewById(R.id.playagainlayout);
        layout.setVisibility(view.VISIBLE);
    }
}


}       }
    }
    public void PLAYAGAINBUTTON(View view)

    {
        LinearLayout layout=(LinearLayout)findViewById(R.id.playagainlayout);
        layout.setVisibility(view.INVISIBLE);
        Active_player =0;
        for(int i=0;i<gamestate.length;i++)
        {
            gamestate[i]=2;
        }
        GridLayout grid=(GridLayout)findViewById(R.id.gridlayout);

        for(int i=0;i<grid.getChildCount();i++)
        {
            ((ImageView)grid.getChildAt(i)).setImageResource(0);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
